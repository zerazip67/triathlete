const sql = require("mssql");

const config = {
  user: "express_user",
  password: "express_user",
  server: "127.0.0.1",
  port: 1433,
  database: "AP_TRIATHLON",
  options: {
    encrypt: false,
    trustServerCertificate: true
  }
};

const pool = new sql.ConnectionPool(config);

const poolConnect = pool.connect()
  .then(p => {
    console.log("✅ Connexion SQL Server réussie");
    return p;
  })
  .catch(err => {
    console.error("❌ Erreur de connexion SQL :", err.message);
    process.exit(1); 
  });

module.exports = { sql, pool, poolConnect };