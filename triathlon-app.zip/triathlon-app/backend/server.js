const express = require("express");
const { pool, poolConnect } = require("./db");

const app = express();
const PORT = 3001;
const cors = require("cors");
const bcrypt = require("bcrypt");
const saltRounds = 10;

app.use(express.json());
app.use(cors());
// test
app.get("/", (req, res) => res.send("API Triathlon OK 🚀"));

app.get("/test-db", async (req, res) => {
  try {
    await poolConnect;
    const result = await pool.request().query("SELECT 1 AS test");
    res.json(result.recordset);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.listen(PORT, () => {
  console.log(`✅ Serveur sur http://localhost:${PORT}`);
});

// fin test 

//Inscription
app.post("/register", async (req, res) => {
    const { nom, prenom, sexe, adresseRue, adresseCP, adresseVille, dateNaissance, login, mdp } = req.body;
    try{
        await poolConnect;
        const request = pool.request();

        const maxId = await request.query("SELECT MAX(numLicence) AS lastId FROM Triathlete");
        const nextId = (maxId.recordset[0].lastId || 0) + 1;
        const hashedMdp = await bcrypt.hash(mdp, saltRounds);

        request.input("numLicence", nextId);
        request.input("nom", nom);
        request.input("prenom", prenom);
        request.input("sexe", sexe);
        request.input("adresseRue", adresseRue);
        request.input("adresseCP", adresseCP);
        request.input("adresseVille", adresseVille);
        request.input("dateNaissance", dateNaissance);
        request.input("code", 1)

        await request.query("INSERT INTO Triathlete(numLicence, nom, prenom, sexe, adresseRue, adresseCP, adresseVille, dateNaissance, code) VALUES(@numLicence, @nom, @prenom, @sexe, @adresseRue, @adresseCP, @adresseVille, @dateNaissance, @code)");

        request.input("login", login);
        request.input("mdp", hashedMdp);
        request.input("statut", null);

        await request.query("INSERT INTO Utilisateur(login, mdp, tri_licence, statut) VALUES(@login, @mdp, @numLicence, @statut)");
        res.json({ message: "Inscrit avec l'ID " + nextId });
    }
    catch (err) { 
    console.log("❌ Erreur détectée lors de l'insertion :");
    console.error(err); 
    res.status(500).send(err.message);
}
});

//Connexion
app.post("/login", async(req, res) => {
    const { login, mdp } = req.body;
    try{
        await poolConnect;
        const request = pool.request();
        request.input("login", login);

        const result = await request.query("SELECT u.mdp as hashedMdp, t.* FROM Utilisateur u JOIN Triathlete t ON u.tri_licence = t.numLicence WHERE u.login = @login");
        if (result.recordset.length === 0) {
            return res.status(401).json({ message: "Identifiant incorrect" });
        }
        const user = result.recordset[0];

        const match = await bcrypt.compare(mdp, user.hashedMdp);

        if (match) {
            delete user.hashedMdp;
            
            res.json({ 
                message: "Connexion réussie", 
                user: user 
            });
        } else {
            res.status(401).json({ message: "Mot de passe incorrect" });
        }

    } catch (err) {
        console.error("Erreur Login:", err);
        res.status(500).send("Erreur serveur");
    }
});

// liste triathlons
app.get("/triathlons/futurs", async (req, res) => {
    try {
        await poolConnect;
        const result = await pool.request().query(`
            SELECT idT, nomT, dateT, lieuT, codeType 
            FROM dbo.Triathlon 
            WHERE dateT >= CAST(GETDATE() AS DATE) 
            ORDER BY dateT ASC
        `);
        res.json(result.recordset);
    } catch (err) {
        console.error("Erreur récupération triathlons :", err);
        res.status(500).send("Erreur serveur");
    }
});

// detail epreuve
app.get("/triathlon/:id/epreuves", async (req, res) => {
    const idT = req.params.id;

    const query = `
        SELECT 
            e.numEpreuve, e.gpsDepart, e.gpsArrivee,
            CASE 
                WHEN n.numEpreuve IS NOT NULL THEN 'natation'
                WHEN v.numEpreuve IS NOT NULL THEN 'velo'
                WHEN p.numEpreuve IS NOT NULL THEN 'course'
            END as type_epreuve,
            n.temperature,
            v.pente,
            c.denivelePositif, c.deniveleNegatif
        FROM dbo.Epreuve e
        LEFT JOIN dbo.Natation n ON e.numEpreuve = n.numEpreuve
        LEFT JOIN dbo.Course_Velo v ON e.numEpreuve = v.numEpreuve
        LEFT JOIN dbo.Course_Pied p ON e.numEpreuve = p.numEpreuve
        LEFT JOIN dbo.Course c ON e.numEpreuve = c.numEpreuve
        WHERE e.idT = @idTriathlon;
    `;

    try {
        await poolConnect;
        const request = pool.request();
        
        request.input("idTriathlon", idT);
        
        const result = await request.query(query);
        const rows = result.recordset || [];

        const response = {
            natation: rows.find(e => e.type_epreuve === 'natation') || null,
            velo: rows.find(e => e.type_epreuve === 'velo') || null,
            course: rows.find(e => e.type_epreuve === 'course') || null
        };

        res.json(response);

    } catch (err) {
        console.error("❌ Erreur lors de la récupération des épreuves :", err);
    
        res.status(500).json({ 
            error: "Erreur lors de la récupération des épreuves", 
            details: err.message 
        });
    }
});

// S'inscrire ou se désinscrire d'un triathlon
app.post("/triathlon/:id/inscription", async (req, res) => {
    const idT = req.params.id;
    const { numLicence } = req.body;

    if (!numLicence) {
        return res.status(400).json({ error: "Utilisateur non connecté ou licence manquante" });
    }

    try {
        await poolConnect;
        const request = pool.request();
        request.input("idT", idT);
        request.input("numLicence", numLicence);

        const checkCheck = await request.query(`
            SELECT * FROM dbo.Inscription 
            WHERE idT = @idT AND numLicence = @numLicence
        `);

        if (checkCheck.recordset.length > 0) {
            await request.query(`
                DELETE FROM dbo.Inscription 
                WHERE idT = @idT AND numLicence = @numLicence
            `);
            return res.json({ isInscrit: false, message: "Désinscription réussie !" });
        } else {
            const maxDossardResult = await request.query(`
                SELECT MAX(numDossard) AS lastDossard 
                FROM dbo.Inscription 
                WHERE idT = @idT
            `);
            
            const nextDossard = (maxDossardResult.recordset[0].lastDossard || 0) + 1;

            request.input("numDossard", nextDossard);

            await request.query(`
                INSERT INTO dbo.Inscription (idT, numLicence, numDossard, dateInscription) 
                VALUES (@idT, @numLicence, @numDossard, GETDATE())
            `);
            
            return res.json({ 
                isInscrit: true, 
                message: `Inscription réussie ! Votre numéro de dossard est le ${nextDossard}. Bonne course ! 🏁` 
            });
        }

    } catch (err) {
        console.error("Erreur Inscription/Désinscription :", err);
        res.status(500).send(err.message);
    }
});

// Route pour savoir si l'utilisateur est déjà inscrit au chargement de la page
app.get("/triathlon/:id/statut-inscription/:numLicence", async (req, res) => {
    try {
        await poolConnect;
        const result = await pool.request()
            .input("idT", req.params.id)
            .input("numLicence", req.params.numLicence)
            .query("SELECT 1 FROM dbo.Inscription WHERE idT = @idT AND numLicence = @numLicence");
            
        res.json({ isInscrit: result.recordset.length > 0 });
    } catch (err) {
        res.status(500).send(err.message);
    }
});