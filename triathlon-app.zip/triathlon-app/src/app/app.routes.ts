import { Routes } from '@angular/router';
import { About } from './about/about';
import { App } from './app';
import { Accueil } from './accueil/accueil';
import { Connexion } from './connexion/connexion';
import { Inscription } from './inscription/inscription';
import { ListeTriathlon } from './liste-triathlon/liste-triathlon';
import { DetailTriathlon } from './detail-triathlon/detail-triathlon';

export const routes: Routes = [
    {path: '', redirectTo: 'accueil', pathMatch: 'full'},
    {path: "about", component: About},
    {path: "accueil", component: Accueil},
    {path: "connexion", component: Connexion},
    {path: "inscription", component: Inscription},
    {path: "liste-triathlon", component: ListeTriathlon},
    {path: "triathlon/:id/epreuves", component: DetailTriathlon}
];
