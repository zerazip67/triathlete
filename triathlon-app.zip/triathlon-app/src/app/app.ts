import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Entete } from "./static/entete/entete";
import { Navbar } from './static/navbar/navbar';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Entete, Navbar],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  protected readonly title = signal('triathlon-app');
}
