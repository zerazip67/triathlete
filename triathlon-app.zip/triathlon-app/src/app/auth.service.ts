import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  estConnecte = signal<boolean>(localStorage.getItem('estConnecte') === '1');

  setLogin(user: any) {
    localStorage.setItem('estConnecte', '1');
    localStorage.setItem('user', JSON.stringify(user));
    this.estConnecte.set(true);
  }

  setLogout() {
    localStorage.removeItem('estConnecte');
    localStorage.removeItem('user');
    this.estConnecte.set(false);
  }
}