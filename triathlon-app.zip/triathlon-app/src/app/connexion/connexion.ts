import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from "@angular/router";
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-connexion',
  standalone: true,
  imports: [FormsModule, RouterLink],
  templateUrl: './connexion.html',
  styleUrl: './connexion.scss',
})
export class Connexion {
  identifiant: string ='';
  password: string='';

  private http = inject(HttpClient);
  private authService = inject(AuthService);
  private router = inject(Router);

  onConnexion()
  {
    if(!this.identifiant || !this.password) {alert("Veuillez remplir tout les champs"); return;}
    const data = { login: this.identifiant, mdp: this.password};
    this.http.post('http://localhost:3001/login', data).subscribe({
      next: (response: any) => {
        console.log("Connexion reussie", response);
        this.authService.setLogin(response.user);
        this.router.navigate(['/accueil']);
        alert("Connexion reussie !");
      },
      error: (err) => {
        console.error('Erreur lors de l\'envoi : ', err);
        alert("Erreur lors de la connexion");
      }
    });
  }
}
