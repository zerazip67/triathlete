import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailTriathlon } from './detail-triathlon';

describe('DetailTriathlon', () => {
  let component: DetailTriathlon;
  let fixture: ComponentFixture<DetailTriathlon>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DetailTriathlon],
    }).compileComponents();

    fixture = TestBed.createComponent(DetailTriathlon);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
