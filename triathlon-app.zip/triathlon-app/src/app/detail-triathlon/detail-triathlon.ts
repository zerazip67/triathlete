import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-detail-triathlon',
  imports: [CommonModule],
  templateUrl: './detail-triathlon.html',
  styleUrl: './detail-triathlon.scss',
})
export class DetailTriathlon implements OnInit {
  dataEpreuves: any = null;
  idT: string | null = null;
  
  // Variables gestion utilisateur
  numLicence: number | null = null;
  isInscrit: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.idT = this.route.snapshot.paramMap.get('id');
    
    // Récupération du triathlète connecté (on suppose que tu stockes l'objet user après le login)
    const userConnected = localStorage.getItem('user'); // ou via un auth.service
    if (userConnected) {
      const user = JSON.parse(userConnected);
      this.numLicence = user.numLicence; // Récupère le numLicence de ta table Triathlete
    }

    // Charger les épreuves
    this.http.get(`http://localhost:3001/triathlon/${this.idT}/epreuves`)
      .subscribe({
        next: (res) => {
          this.dataEpreuves = res;
          this.cdr.detectChanges();
        }
      });

    // Charger le statut de l'inscription si le triathlète est connecté
    if (this.numLicence && this.idT) {
      this.http.get(`http://localhost:3001/triathlon/${this.idT}/statut-inscription/${this.numLicence}`)
        .subscribe({
          next: (res: any) => {
            this.isInscrit = res.isInscrit;
            this.cdr.detectChanges();
          }
        });
    }
  }

  // Action du bouton
  toggleInscription(): void {
    if (!this.numLicence) {
      alert("Vous devez être connecté pour vous inscrire !");
      return;
    }

    this.http.post(`http://localhost:3001/triathlon/${this.idT}/inscription`, { numLicence: this.numLicence })
      .subscribe({
        next: (res: any) => {
          this.isInscrit = res.isInscrit; // On met à jour l'état du bouton (vrai/faux)
          alert(res.message);
          this.cdr.detectChanges();
        },
        error: (err) => alert("Erreur lors de l'action : " + err.error)
      });
  }
}