import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from "@angular/router";
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-inscription',
  imports: [FormsModule, RouterLink],
  templateUrl: './inscription.html',
  styleUrl: './inscription.scss',
})
export class Inscription {
  nom: string ='';
  prenom: string ='';
  sexe: string ='H';
  adresseRue: string ='';
  adresseCP: string ='';
  adresseVille: string='';
  dateNaissance: string='';

  identifiant: string ='';
  mdp: string='';
  confirmerMdp: string='';

  private http = inject(HttpClient);

  onSinscrire() 
  {
    if(!this.nom || !this.prenom || !this.adresseCP || !this.adresseRue || !this.adresseVille || !this.dateNaissance || !this.identifiant || !this.mdp || !this.confirmerMdp){alert("Veuillez remplir tout les champs"); return;}
    if(this.mdp !== this.confirmerMdp){alert("Les mots de passe ne sont pas identique"); return;}
      const data = { nom: this.nom, prenom: this.prenom, sexe: this.sexe, adresseRue: this.adresseRue, adresseCP: this.adresseCP, adresseVille: this.adresseVille, dateNaissance: this.dateNaissance, login: this.identifiant, mdp: this.mdp}

      this.http.post('http://localhost:3001/register', data).subscribe({
        next: (response) => {
          console.log('reponse serveur : ', response);
          alert('Inscription réussie !');
        },
        error: (err) => {
          console.error('Erreur lors de l\'envoi : ', err);
          alert("Erreur lors de l'inscription");
        }
      });
  }
}
