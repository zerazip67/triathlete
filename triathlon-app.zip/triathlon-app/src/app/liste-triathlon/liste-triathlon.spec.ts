import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListeTriathlon } from './liste-triathlon';

describe('ListeTriathlon', () => {
  let component: ListeTriathlon;
  let fixture: ComponentFixture<ListeTriathlon>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ListeTriathlon],
    }).compileComponents();

    fixture = TestBed.createComponent(ListeTriathlon);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
