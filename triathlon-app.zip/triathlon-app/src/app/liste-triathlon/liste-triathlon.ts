import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit, signal} from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-liste-triathlon',
  imports: [DatePipe, RouterLink],
  templateUrl: './liste-triathlon.html',
  styleUrl: './liste-triathlon.scss',
})

export class ListeTriathlon implements OnInit {

  triathlons = signal<any[]>([]); 
  private http = inject(HttpClient);

  ngOnInit() {
    this.http.get<any[]>('http://localhost:3001/triathlons/futurs').subscribe({
      next: (data) => {
        this.triathlons.set(data); // On met à jour le signal
        console.log("Données chargées :", data);
      }
    });
  }
}