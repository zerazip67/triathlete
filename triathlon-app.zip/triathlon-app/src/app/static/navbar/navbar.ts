import { Component, inject } from '@angular/core';
import { Router, RouterLink } from "@angular/router";
import { NgIf } from '@angular/common';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink, NgIf],
  templateUrl: './navbar.html',
  styleUrl: './navbar.scss',
})
export class Navbar {
  protected auth = inject(AuthService);
  private router = inject(Router);

  protected onLogout(): void {
    this.auth.setLogout();
    this.router.navigate(['/accueil']);
  }
}
